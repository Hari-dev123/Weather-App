const apiId = "1348bfa57632645b961f854a16ef9a20";
const apiURL = "https://api.openweathermap.org/data/2.5/weather?units=metric";
const input = document.querySelector('.search input');
const btn = document.querySelector('.search button');
const imgs = document.querySelector('.weather-icon');
const weatherContainer = document.querySelector('.weather');
const errors = document.querySelector('.error');
async function checkWeather(city) {
    try {
        const response = await fetch(`${apiURL}&q=${city}&appid=${apiId}`);
        if (response.status == 404) {
            errors.classList.add('visible')
        }
        const data = await response.json();
        console.log(data);
        if (data.weather[0].main === "Clouds") {
            imgs.src = "/images/clouds.png";
        } else if (data.weather[0].main === "Clear") {
            imgs.src = "/images/clear.png";
        } else if (data.weather[0].main === "Drizzle") {
            imgs.src = "/images/drizzle.png";
        } else if (data.weather[0].main === "Rain") {
            imgs.src = "/images/rain.png";
        } else if (data.weather[0].main === "Mist") {
            imgs.src = "/images/mist.png";
        }
        document.querySelector('.temp').innerHTML = Math.round(data.main.temp) + "°C";
        document.querySelector('.city').innerHTML = data.name;
        document.querySelector('.humidity').innerHTML = data.main.humidity + "%";
        document.querySelector('.wind').innerHTML = data.wind.speed + " Km/h";
        weatherContainer.classList.add('visible'); 
    } catch (error) {
        console.error('Error fetching weather data:', error);
    }
}
btn.addEventListener('click', () => {
    checkWeather(input.value);
});
